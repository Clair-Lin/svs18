<template>
  <div class="app-detail">
    <header class="app-detail__head">
      <div class="app-detail__nav">
        <el-button link type="primary" class="app-detail__back" @click="goApplicationList">
          <el-icon><ArrowLeft /></el-icon>
          返回
        </el-button>
        <span class="app-detail__nav-hint">应用详情</span>
      </div>
      <h2 class="app-detail__title">应用详情</h2>
      <p class="app-detail__meta">
        当前应用：<strong>{{ appName }}</strong>（ID：{{ appId }}）
      </p>
    </header>

    <div class="page-card app-detail__panel">
      <div class="section-head">
        <span class="section-bar" />
        <span class="section-title">基本信息</span>
      </div>
      <el-descriptions :column="2" border class="basic-desc">
        <el-descriptions-item label="应用名称">{{ appName }}</el-descriptions-item>
        <el-descriptions-item label="应用 ID">{{ appId }}</el-descriptions-item>
        <el-descriptions-item label="应用状态">
          <el-tag :type="appStatus === '启用' ? 'success' : 'info'" size="small">{{ appStatus }}</el-tag>
        </el-descriptions-item>
        <el-descriptions-item label="创建时间">{{ createTime || '—' }}</el-descriptions-item>
      </el-descriptions>
    </div>

    <div class="page-card app-detail__panel app-detail__auth-panel">
      <div class="section-head section-head--with-tip">
        <span class="section-bar" />
        <span class="section-title">接口鉴权</span>
        <span class="section-sub">接入安全配置 · 应用级</span>
      </div>

      <el-alert type="info" :closable="false" show-icon class="auth-scope-alert">
        <template #title>配置范围说明</template>
        <ul class="auth-scope-list">
          <li>
            本区域为<strong>接入安全配置</strong>，用于控制第三方系统调用 SVS 开放接口时的身份与权限，<strong>不是</strong>业务证书、根证书等<strong>业务证书配置</strong>。
          </li>
          <li>
            以下配置按<strong>应用</strong>维度生效，属于<strong>应用级配置</strong>；业务侧证书、密钥绑定等请在「证书配置」「根证书配置」中维护，<strong>不是</strong>业务级接口鉴权项。
          </li>
        </ul>
      </el-alert>

      <el-form
        ref="authFormRef"
        :model="authForm"
        :rules="authRules"
        label-width="140px"
        class="auth-form"
      >
        <el-form-item label="接口鉴权状态" prop="authStatus">
          <el-radio-group v-model="authForm.authStatus">
            <el-radio label="启用">启用</el-radio>
            <el-radio label="停用">停用</el-radio>
          </el-radio-group>
          <p v-if="authForm.authStatus === '停用'" class="auth-disabled-tip">
            停用后该应用调用接口时不再校验 HMAC-SM3 签名，但仍会校验应用状态和授权范围。建议仅在联调或过渡期使用。
          </p>
        </el-form-item>

        <el-form-item label="鉴权方式">
          <el-input model-value="HMAC-SM3" readonly class="auth-readonly-input" />
          <span class="form-hint">
            本版本固定为 HMAC-SM3。调用方在请求头中携带<strong>应用 ID</strong>（与上方基本信息一致），服务端根据应用 ID 查找应用密钥并验签。
          </span>
        </el-form-item>

        <div id="app-credentials" class="credentials-block">
        <el-form-item label="应用密钥">
          <div class="readonly-field-row">
            <span class="readonly-value readonly-value--secret">{{ secretDisplay }}</span>
            <el-button plain @click="resetSecret">重置</el-button>
            <el-button @click="copyText(authForm.secret, '应用密钥')">复制</el-button>
          </div>
          <span class="form-hint">
            由系统在创建应用时自动生成，与<strong>应用 ID</strong>配对用于 HMAC-SM3 签名；请妥善保管，勿写入前端或日志。
          </span>
        </el-form-item>
        </div>

        <el-form-item label="请求有效期" prop="requestTtlMinutes">
          <el-input-number
            v-model="authForm.requestTtlMinutes"
            :min="1"
            :max="60"
            :step="1"
            controls-position="right"
          />
          <span class="form-unit">分钟</span>
          <span class="form-hint">客户端请求时间戳与服务器时间差超过该值将被拒绝，默认 5 分钟。</span>
        </el-form-item>

        <el-form-item label="允许调用范围" prop="allowedScopes">
          <el-checkbox-group v-model="authForm.allowedScopes">
            <el-checkbox label="签名">签名</el-checkbox>
            <el-checkbox label="验签">验签</el-checkbox>
          </el-checkbox-group>
          <span class="form-hint block-hint">本轮仅覆盖 0029 侧签名、验签接口。</span>
        </el-form-item>
      </el-form>

      <div class="footer-actions">
        <el-button type="primary" :loading="saving" @click="saveAuthConfig">保存配置</el-button>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, reactive, computed, watchEffect, onMounted } from 'vue'
import { useRoute, useRouter } from 'vue-router'
import { setPageBreadcrumbItems } from '@/composables/pageBreadcrumb'
import { ElMessage, ElMessageBox } from 'element-plus'
import { ArrowLeft } from '@element-plus/icons-vue'
import {
  genAppSecret,
  maskSecret,
  loadApiAuth,
  persistApiAuth,
  normalizeApiAuth,
  initApiAuthForApp,
  recordApiAuthAudit
} from '@/utils/appApiAuth'

const route = useRoute()
const router = useRouter()

const appId = computed(() => String(route.query.appId || '').trim())
const appName = computed(() => String(route.query.name || '').trim() || '未命名应用')
const appStatus = computed(() => String(route.query.status || '启用'))
const createTime = computed(() => String(route.query.createTime || ''))

watchEffect(() => {
  setPageBreadcrumbItems([
    { label: '应用管理', to: '/application' },
    { label: '应用详情' }
  ])
})

const authFormRef = ref(null)
const saving = ref(false)
const secretPlainVisible = ref(false)

const authForm = reactive({
  method: 'HMAC-SM3',
  secret: '',
  requestTtlMinutes: 5,
  allowedScopes: ['签名', '验签'],
  authStatus: '停用'
})

const authRules = {
  requestTtlMinutes: [
    { required: true, message: '请填写请求有效期', trigger: 'blur' },
    {
      type: 'number',
      min: 1,
      max: 60,
      message: '请求有效期为 1～60 分钟',
      trigger: 'change'
    }
  ],
  allowedScopes: [
    {
      type: 'array',
      required: true,
      min: 1,
      message: '请至少选择签名或验签其中一项',
      trigger: 'change'
    }
  ],
  authStatus: [{ required: true, message: '请选择接口鉴权状态', trigger: 'change' }]
}

const secretDisplay = computed(() => {
  if (!authForm.secret) return maskSecret('')
  if (secretPlainVisible.value) return authForm.secret
  return maskSecret(authForm.secret)
})

function applyAuthData (data) {
  const normalized = normalizeApiAuth(appId.value, data)
  Object.assign(authForm, {
    method: normalized.method,
    secret: normalized.secret,
    requestTtlMinutes: normalized.requestTtlMinutes,
    allowedScopes: [...normalized.allowedScopes],
    authStatus: normalized.authStatus
  })
}

function initAuthForm () {
  const stored = loadApiAuth(appId.value)
  if (stored) {
    applyAuthData(stored)
    persistApiAuth(appId.value, authForm)
    return
  }
  const initial = initApiAuthForApp(appId.value)
  applyAuthData(initial)
}

onMounted(() => {
  if (!appId.value) {
    ElMessage.warning('缺少应用 ID，请从应用管理进入')
    return
  }
  initAuthForm()
  const section = route.query.section
  if (section === 'api-auth') {
    document.querySelector('.app-detail__auth-panel')?.scrollIntoView({ behavior: 'smooth', block: 'start' })
  } else if (section === 'credentials') {
    document.getElementById('app-credentials')?.scrollIntoView({ behavior: 'smooth', block: 'center' })
  }
})

function goApplicationList () {
  router.push('/application')
}

async function copyText (text, label) {
  if (!text) {
    ElMessage.warning(`暂无${label}可复制`)
    return
  }
  try {
    await navigator.clipboard.writeText(text)
    ElMessage.success(`${label}已复制`)
  } catch {
    ElMessage.info(`${label}：${text}（原型环境请手动复制）`)
  }
}

function resetSecret () {
  ElMessageBox.confirm(
    '重置后原密钥立即失效，使用该密钥的应用将无法调用接口',
    '重置应用密钥',
    { type: 'warning', confirmButtonText: '确定重置', cancelButtonText: '取消' }
  )
    .then(() => {
      authForm.secret = genAppSecret()
      secretPlainVisible.value = true
      recordApiAuthAudit({
        appId: appId.value,
        appName: appName.value,
        action: '重置应用密钥',
        detail: `应用 ID ${appId.value}，HMAC-SM3 应用密钥已轮换`
      })
      persistApiAuth(appId.value, authForm)
      ElMessage.success('应用密钥已重置，审计日志已记录（原型演示）')
      setTimeout(() => {
        secretPlainVisible.value = false
      }, 8000)
    })
    .catch(() => {})
}

function saveAuthConfig () {
  authFormRef.value?.validate((valid) => {
    if (!valid) return
    saving.value = true
    setTimeout(() => {
      persistApiAuth(appId.value, authForm)
      saving.value = false
      ElMessage.success('接口鉴权配置已保存（原型演示）')
    }, 300)
  })
}
</script>

<style lang="scss" scoped>
@import '@/styles/variables.scss';

.app-detail {
  display: flex;
  flex-direction: column;
  gap: 16px;
}

.app-detail__head {
  .app-detail__nav {
    display: flex;
    align-items: center;
    gap: 12px;
    margin-bottom: 8px;
  }

  .app-detail__back {
    padding-left: 0;
    font-size: 13px;
  }

  .app-detail__nav-hint {
    font-size: 13px;
    color: $text-secondary;
  }

  .app-detail__title {
    margin: 0 0 8px;
    font-size: 18px;
    font-weight: 600;
    color: $text-primary;
  }

  .app-detail__meta {
    margin: 0;
    font-size: 13px;
    color: $text-secondary;

    strong {
      color: $text-primary;
      font-weight: 500;
    }
  }
}

.app-detail__panel {
  padding: 20px 24px;
}

.section-head {
  display: flex;
  align-items: center;
  gap: 8px;
  margin-bottom: 16px;

  &--with-tip {
    flex-wrap: wrap;
  }
}

.section-bar {
  width: 3px;
  height: 16px;
  background: $primary-color;
  border-radius: 2px;
  flex-shrink: 0;
}

.section-title {
  font-size: 15px;
  font-weight: 600;
  color: $text-primary;
}

.section-sub {
  font-size: 12px;
  color: $text-secondary;
  margin-left: 4px;
}

.basic-desc {
  max-width: 900px;
}

.auth-scope-alert {
  margin-bottom: 20px;

  :deep(.el-alert__title) {
    font-weight: 600;
  }
}

.auth-scope-list {
  margin: 8px 0 0;
  padding-left: 18px;
  font-size: 13px;
  line-height: 1.7;
  color: $text-secondary;

  li + li {
    margin-top: 4px;
  }

  strong {
    color: $text-primary;
    font-weight: 600;
  }
}

.auth-form {
  max-width: 720px;

  .form-hint {
    display: block;
    margin-top: 6px;
    font-size: 12px;
    color: $text-secondary;
    line-height: 1.5;

    &.block-hint {
      margin-top: 4px;
    }
  }

  .form-unit {
    margin-left: 8px;
    font-size: 13px;
    color: $text-secondary;
  }
}

.auth-disabled-tip {
  margin: 8px 0 0;
  padding: 8px 12px;
  font-size: 13px;
  line-height: 1.6;
  color: #ad6800;
  background: #fffbe6;
  border: 1px solid #ffe58f;
  border-radius: 4px;
}

.auth-readonly-input {
  max-width: 280px;

  :deep(.el-input__wrapper) {
    background: #f5f7fa;
  }
}

.readonly-field-row {
  display: flex;
  flex-wrap: wrap;
  align-items: center;
  gap: 12px;
  width: 100%;
}

.readonly-value {
  font-size: 14px;
  font-family: Consolas, 'Courier New', monospace;
  color: $text-primary;
  word-break: break-all;
  line-height: 1.5;
  padding: 6px 0;
  min-width: 200px;
  max-width: 420px;

  &--secret {
    letter-spacing: 0.5px;
  }
}

.footer-actions {
  margin-top: 24px;
  padding-top: 16px;
  border-top: 1px solid #f0f0f0;
}
</style>
