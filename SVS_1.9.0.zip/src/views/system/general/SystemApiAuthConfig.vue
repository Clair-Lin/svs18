<template>
  <div class="system-api-auth">
    <div class="page-card">
      <div class="card-title">接口鉴权</div>

      <el-alert type="info" :closable="false" show-icon class="scope-alert">
        <template #title>系统通用配置</template>
        本页为<strong>系统级</strong>接口鉴权通用策略。各应用的密钥、启用状态与调用范围请在
        <router-link to="/application" class="link-application">应用管理</router-link>
        中按应用单独配置。
      </el-alert>

      <el-form
        ref="formRef"
        :model="form"
        :rules="rules"
        label-width="160px"
        class="config-form"
      >
        <el-form-item label="系统级接口鉴权">
          <el-switch
            v-model="form.globalEnabled"
            inline-prompt
            active-text="启用"
            inactive-text="关闭"
          />
          <span class="form-hint">关闭后，全系统开放接口不再执行 HMAC-SM3 鉴权（原型演示）。</span>
        </el-form-item>

        <el-form-item label="鉴权方式">
          <el-input model-value="HMAC-SM3" readonly class="readonly-input" />
          <span class="form-hint">本版本固定为 HMAC-SM3。调用方在请求头中携带<strong>应用 ID</strong>，服务端据此查找应用密钥验签。</span>
        </el-form-item>

        <el-form-item label="默认请求有效期" prop="defaultRequestTtlMinutes">
          <el-input-number
            v-model="form.defaultRequestTtlMinutes"
            :min="1"
            :max="60"
            :step="1"
            controls-position="right"
          />
          <span class="form-unit">分钟</span>
          <span class="form-hint">新建应用时接口鉴权配置的默认有效期，应用可在应用管理中单独调整。</span>
        </el-form-item>
      </el-form>

      <div class="footer-actions">
        <el-button type="primary" :loading="saving" @click="onSave">保存配置</el-button>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, reactive, onMounted } from 'vue'
import { ElMessage } from 'element-plus'
import { loadSystemApiAuth, persistSystemApiAuth } from '@/utils/systemApiAuth'

const formRef = ref(null)
const saving = ref(false)

const form = reactive({
  globalEnabled: true,
  method: 'HMAC-SM3',
  defaultRequestTtlMinutes: 5
})

const rules = {
  defaultRequestTtlMinutes: [
    { required: true, message: '请填写默认请求有效期', trigger: 'blur' },
    {
      type: 'number',
      min: 1,
      max: 60,
      message: '有效期为 1～60 分钟',
      trigger: 'change'
    }
  ]
}

function loadForm () {
  const data = loadSystemApiAuth()
  form.globalEnabled = data.globalEnabled
  form.method = data.method
  form.defaultRequestTtlMinutes = data.defaultRequestTtlMinutes
}

onMounted(loadForm)

function onSave () {
  formRef.value?.validate((valid) => {
    if (!valid) return
    saving.value = true
    setTimeout(() => {
      persistSystemApiAuth(form)
      saving.value = false
      ElMessage.success('系统通用接口鉴权配置已保存（原型演示）')
    }, 300)
  })
}
</script>

<style lang="scss" scoped>
@import '@/styles/variables.scss';

.system-api-auth {
  .card-title {
    font-size: 16px;
    font-weight: 600;
    color: $text-primary;
    margin-bottom: 16px;
  }

  .scope-alert {
    margin-bottom: 20px;

    .link-application {
      color: $primary-color;
      text-decoration: none;

      &:hover {
        text-decoration: underline;
      }
    }
  }

  .config-form {
    max-width: 720px;

    .form-hint {
      display: block;
      margin-top: 6px;
      font-size: 12px;
      color: $text-secondary;
      line-height: 1.5;
    }

    .form-unit {
      margin-left: 8px;
      font-size: 13px;
      color: $text-secondary;
    }
  }

  .readonly-input {
    max-width: 280px;

    :deep(.el-input__wrapper) {
      background: #f5f7fa;
    }
  }

  .footer-actions {
    margin-top: 24px;
    padding-top: 16px;
    border-top: 1px solid #f0f0f0;
  }
}
</style>
